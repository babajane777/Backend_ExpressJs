 var discription = document.getElementById("floatingTextarea");
 var date =  document.getElementById("floatingInputGrid");
 var category =  document.getElementById("floatingSelectGrid");

 function reset(){
    discription.value ="";
    date.value = "";
    category.value = ""
 }